package com.vanguarda.hotelaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
