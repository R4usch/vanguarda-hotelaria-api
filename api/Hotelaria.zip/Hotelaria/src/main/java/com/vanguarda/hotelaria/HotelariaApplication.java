package com.vanguarda.hotelaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelariaApplication.class, args);
	}

}
